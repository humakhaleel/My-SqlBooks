const {Sequelize} = require('sequelize');


const sequelize = new Sequelize({
    host:'localhost',
    dialect:'mysql',
    username:'root',
    password:'Publication1@',
    port:3306,
    database:'bookschema'
});

module.exports = sequelize;