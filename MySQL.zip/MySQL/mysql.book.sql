SELECT * FROM bookschema.books;

