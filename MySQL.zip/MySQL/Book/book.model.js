const sequelize = require("../sequelize/config");
const { DataTypes } = require("sequelize");




const Books = sequelize.define('Books',{
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
        allowNull: false
    },
    Title:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    Author:{
        type: DataTypes.STRING,
        allowNull: false,
        },
    Publisher:{
        type: DataTypes.STRING,
        allowNull: false,
        }, 
},{timestamps:true, createdAt:true,updatedAt:true,tableName:'Books'});





module.exports = Books;