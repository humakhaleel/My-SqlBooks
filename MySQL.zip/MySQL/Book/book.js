const Books = require('../Book/book.model');

const addBooks = async (books)=>{
    const createBooks = await Books.create(books);
    console.log(createBooks);
    return createBooks;
};

const selectbook = async (bookid)=>{
    const getbook = await Books.findOne({where:{id:bookid}});
     return getbook
};

const updatebook = async(bookid,bookdetail)=>{
    const newbook = await Books.findOne({where: {id:bookid}});
    if(!newbook){
        return {message: "book not found"};
        }else{
        const bookdata = Books.update(bookdetail,{where:{id:bookid}});
        return bookdata;
}
}

const deletebook = async(bookid)=>{
    const deletebook = await Books.findOne({where:{id:bookid}});
    if (!deletebook) {
        return { message: "book not found" }; 
    }else{
    const delbook = await Books.destroy({where:{id:bookid}});
    return delbook
    }
}

module.exports={
    addBooks,
    selectbook,
    updatebook,
    deletebook
}