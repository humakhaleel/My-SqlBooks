const express=require('express');
const { addBooks, selectbook, updatebook, deletebook } = require('./book');

const router = express.Router();

router.post("/create",async(req,res)=>{
    const bookData = await addBooks(req.body)
    console.log(bookData);
    res.status(201).json({
        booksdata: bookData,})
});

router.get("/select/:bookid", async(req,res)=>{
    const bookData = await selectbook(Number(req.params.bookid));
    if (!bookData) {
        res.status(404).json({
            message: "Book not found",
        })
    }else{
    res.status(200).json({
        booksdata: bookData
    });
}
});

router.put("/update/:bookid",async(req,res)=>{
    const bookData = await updatebook(Number(req.params.bookid));
    if (!bookData) {
        res.status(404).json({       
});
    }else {
        const updatedBook = await addBooks(req.body);
        res.status(201).json({
            updatedBook,
        });}
});

router.delete("/delete/:bookid",async(req,res)=>{
const bookData = await deletebook(Number(req.params.bookid));
if (!bookData) {
res.status(404).json({
message:'book id not found'
});
}else{
res.status(200).json({
message:'book has delete',
bookData,
});
}
});




module.exports=router;