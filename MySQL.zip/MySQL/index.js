const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./sequelize/config');
const Books = require('./Book/book.model');

const app = express();

const bookrouter = require('./Book/route');


sequelize.authenticate()
.then (async()=>{
    await sequelize.sync();
    await Books.sync({alter:true});
    console.log('Database connected and synced');
}).catch((error)=>{
    console.log('Error connecting to database', error);
});

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
app.use('/book',bookrouter );

app.listen(3012,()=>{
    console.log('server is running on port',3012);
});
